// api/football.js
// Free API: api-football.com (free tier: 100 calls/day)
// Get key at: https://dashboard.api-football.com → Register → API Key
// Set in Vercel: FOOTBALL_API_KEY

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');

  const FOOTBALL_KEY = process.env.FOOTBALL_API_KEY;

  if (!FOOTBALL_KEY || FOOTBALL_KEY === 'YOUR_KEY_HERE') {
    return res.json(getMockFootball());
  }

  try {
    // Get live fixtures from multiple leagues
    const leagueIds = [39, 140, 135, 78, 2]; // EPL, La Liga, Serie A, Bundesliga, UCL
    
    const response = await fetch(
      'https://v3.football.api-sports.io/fixtures?live=all',
      {
        headers: {
          'x-rapidapi-key': FOOTBALL_KEY,
          'x-rapidapi-host': 'v3.football.api-sports.io'
        }
      }
    );
    const data = await response.json();

    if (!data.response || data.response.length === 0) {
      // No live matches, get today's matches
      const todayRes = await fetch(
        `https://v3.football.api-sports.io/fixtures?date=${new Date().toISOString().split('T')[0]}&league=39&season=2024`,
        {
          headers: {
            'x-rapidapi-key': FOOTBALL_KEY,
            'x-rapidapi-host': 'v3.football.api-sports.io'
          }
        }
      );
      const todayData = await todayRes.json();
      const matches = formatFootballMatches(todayData.response || []);
      return res.json({ success: true, source: 'today', matches });
    }

    const matches = formatFootballMatches(data.response);
    return res.json({ success: true, source: 'live', matches });

  } catch (err) {
    console.error('Football API error:', err);
    return res.json(getMockFootball());
  }
}

function formatFootballMatches(fixtures) {
  return fixtures.slice(0, 6).map(f => {
    const fix = f.fixture;
    const teams = f.teams;
    const goals = f.goals;
    const league = f.league;
    const elapsed = fix.status?.elapsed;
    const statusShort = fix.status?.short;

    let status = 'upcoming';
    if (['1H','2H','ET','BT','P','LIVE'].includes(statusShort)) status = 'live';
    else if (['FT','AET','PEN'].includes(statusShort)) status = 'ended';

    const crowdA = 35 + Math.floor(Math.random() * 30);
    return {
      id: fix.id,
      league: league.name,
      teamA: teams.home.name,
      teamB: teams.away.name,
      scoreA: goals.home !== null ? String(goals.home) : '—',
      scoreB: goals.away !== null ? String(goals.away) : '—',
      minute: elapsed ? `${elapsed}'` : statusShort,
      status,
      venue: fix.venue?.name || '',
      crowdA,
      crowdB: 100 - crowdA,
      vol: ['NORMAL','HIGH','EXTREME'][Math.floor(Math.random()*3)],
      momentum: 35 + Math.floor(Math.random()*30)
    };
  });
}

function getMockFootball() {
  return {
    success: true,
    source: 'mock',
    note: 'Set FOOTBALL_API_KEY env var. Get free key at api-football.com',
    matches: [
      {
        id: 'epl-mci-ars', league: 'Premier League', teamA: 'Man City', teamB: 'Arsenal',
        scoreA: '2', scoreB: '1', minute: `${70+Math.floor(Math.random()*15)}'`,
        status: 'live', venue: 'Etihad Stadium',
        crowdA: 58, crowdB: 42, vol: 'HIGH', momentum: 55
      },
      {
        id: 'laliga-bar-rea', league: 'La Liga', teamA: 'Barcelona', teamB: 'Real Madrid',
        scoreA: '1', scoreB: '1', minute: `${85+Math.floor(Math.random()*5)}'`,
        status: 'live', venue: 'Camp Nou',
        crowdA: 51, crowdB: 49, vol: 'EXTREME', momentum: 52
      },
      {
        id: 'ucl-psg-dor', league: 'Champions League', teamA: 'PSG', teamB: 'Dortmund',
        scoreA: '0', scoreB: '0', minute: `${10+Math.floor(Math.random()*20)}'`,
        status: 'live', venue: 'Parc des Princes',
        crowdA: 60, crowdB: 40, vol: 'NORMAL', momentum: 42
      },
      {
        id: 'bun-bay-dor', league: 'Bundesliga', teamA: 'Bayern Munich', teamB: 'B. Dortmund',
        scoreA: '—', scoreB: '—', minute: 'Tomorrow',
        status: 'upcoming', venue: 'Allianz Arena',
        crowdA: 55, crowdB: 45, vol: 'NORMAL', momentum: 50
      },
      {
        id: 'sa-juve-mil', league: 'Serie A', teamA: 'Juventus', teamB: 'AC Milan',
        scoreA: '3', scoreB: '2', minute: 'FT',
        status: 'ended', venue: 'Allianz Stadium',
        crowdA: 46, crowdB: 54, vol: 'HIGH', momentum: 40
      }
    ]
  };
}
