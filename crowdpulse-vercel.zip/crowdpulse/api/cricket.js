// api/cricket.js
// Free API: cricapi.com (free tier: 100 calls/day)
// Get your key at: https://cricapi.com → Dashboard → API Key
// Set in Vercel: Settings → Environment Variables → CRICKET_API_KEY

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  
  const CRICKET_KEY = process.env.CRICKET_API_KEY;
  
  // If no API key, return rich mock data so UI always works
  if (!CRICKET_KEY || CRICKET_KEY === 'YOUR_KEY_HERE') {
    return res.json(getMockCricket());
  }

  try {
    // cricapi.com - currentMatches endpoint
    const response = await fetch(
      `https://api.cricapi.com/v1/currentMatches?apikey=${CRICKET_KEY}&offset=0`,
      { headers: { 'Content-Type': 'application/json' } }
    );
    const data = await response.json();
    
    if (!data.data || data.status !== 'success') {
      return res.json(getMockCricket());
    }

    const matches = data.data.slice(0, 8).map(m => ({
      id: m.id,
      league: m.series_id ? (m.name?.split(',')[1]?.trim() || 'CRICKET') : 'CRICKET',
      teamA: m.teams?.[0] || 'TBA',
      teamB: m.teams?.[1] || 'TBA',
      scoreA: m.score?.[0] ? `${m.score[0].r}/${m.score[0].w}` : '—',
      scoreB: m.score?.[1] ? `${m.score[1].r}/${m.score[1].w}` : '—',
      oversA: m.score?.[0]?.o || '0',
      oversB: m.score?.[1]?.o || '0',
      status: m.matchStarted && !m.matchEnded ? 'live' : m.matchEnded ? 'ended' : 'upcoming',
      venue: m.venue || '',
      matchType: m.matchType || 'T20',
      crowdA: 40 + Math.floor(Math.random() * 20),
      crowdB: 0,
      vol: ['NORMAL','HIGH','EXTREME'][Math.floor(Math.random()*3)],
      momentum: 35 + Math.floor(Math.random() * 30),
    })).map(m => ({ ...m, crowdB: 100 - m.crowdA }));

    return res.json({ success: true, source: 'live', matches });
  } catch (err) {
    console.error('Cricket API error:', err);
    return res.json(getMockCricket());
  }
}

function getMockCricket() {
  const now = new Date();
  return {
    success: true,
    source: 'mock',
    note: 'Set CRICKET_API_KEY env var for live data. Get free key at cricapi.com',
    matches: [
      {
        id: 'ipl-mi-kkr', league: 'IPL 2025', teamA: 'Mumbai Indians', teamB: 'Kolkata KR',
        scoreA: `${167 + Math.floor(Math.random()*20)}/${4+Math.floor(Math.random()*3)}`,
        scoreB: `${142 + Math.floor(Math.random()*15)}/${6+Math.floor(Math.random()*2)}`,
        oversA: '20.0', oversB: `${15+Math.floor(Math.random()*4)}.${Math.floor(Math.random()*6)}`,
        status: 'live', matchType: 'T20', venue: 'Wankhede Stadium',
        crowdA: 45, crowdB: 55, vol: 'EXTREME', momentum: 62
      },
      {
        id: 'ipl-csk-rr', league: 'IPL 2025', teamA: 'Chennai Super Kings', teamB: 'Rajasthan Royals',
        scoreA: `${200 + Math.floor(Math.random()*15)}/${5+Math.floor(Math.random()*2)}`,
        scoreB: '0/0', oversA: '20.0', oversB: '0.0',
        status: 'live', matchType: 'T20', venue: 'MA Chidambaram',
        crowdA: 61, crowdB: 39, vol: 'HIGH', momentum: 38
      },
      {
        id: 'test-ind-aus', league: 'TEST SERIES', teamA: 'India', teamB: 'Australia',
        scoreA: `${320 + Math.floor(Math.random()*20)}/7`, scoreB: '289/10',
        oversA: 'Day 3', oversB: 'All out',
        status: 'live', matchType: 'Test', venue: 'MCG Melbourne',
        crowdA: 72, crowdB: 28, vol: 'NORMAL', momentum: 30
      },
      {
        id: 'ipl-rcb-srh', league: 'IPL 2025', teamA: 'RCB', teamB: 'Sunrisers HYD',
        scoreA: '—', scoreB: '—', oversA: 'Tonight 7PM', oversB: '—',
        status: 'upcoming', matchType: 'T20', venue: 'Chinnaswamy Stadium',
        crowdA: 53, crowdB: 47, vol: 'NORMAL', momentum: 50
      },
      {
        id: 'ipl-dc-pbks', league: 'IPL 2025', teamA: 'Delhi Capitals', teamB: 'Punjab Kings',
        scoreA: `${155+Math.floor(Math.random()*20)}/8`, scoreB: `${160+Math.floor(Math.random()*15)}/6`,
        oversA: '20.0', oversB: `${18+Math.floor(Math.random()*2)}.${Math.floor(Math.random()*6)}`,
        status: 'live', matchType: 'T20', venue: 'Feroz Shah Kotla',
        crowdA: 48, crowdB: 52, vol: 'HIGH', momentum: 55
      },
      {
        id: 'odi-eng-nz', league: 'ODI SERIES', teamA: 'England', teamB: 'New Zealand',
        scoreA: `${245+Math.floor(Math.random()*30)}/7`, scoreB: '0/0',
        oversA: '50.0', oversB: '0.0',
        status: 'live', matchType: 'ODI', venue: "Lord's Cricket Ground",
        crowdA: 55, crowdB: 45, vol: 'NORMAL', momentum: 45
      }
    ]
  };
}
