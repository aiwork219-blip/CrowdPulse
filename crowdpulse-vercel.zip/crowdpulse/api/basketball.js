// api/basketball.js
// Free API: api-nba.com via RapidAPI (free tier: 100 calls/day)
// Get key at: https://rapidapi.com/api-sports/api/api-nba
// Set in Vercel: RAPIDAPI_KEY

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');

  const RAPIDAPI_KEY = process.env.RAPIDAPI_KEY;

  if (!RAPIDAPI_KEY || RAPIDAPI_KEY === 'YOUR_KEY_HERE') {
    return res.json(getMockNBA());
  }

  try {
    const today = new Date().toISOString().split('T')[0];
    const response = await fetch(
      `https://api-nba-v1.p.rapidapi.com/games?date=${today}`,
      {
        headers: {
          'x-rapidapi-key': RAPIDAPI_KEY,
          'x-rapidapi-host': 'api-nba-v1.p.rapidapi.com'
        }
      }
    );
    const data = await response.json();

    if (!data.response || data.response.length === 0) {
      return res.json(getMockNBA());
    }

    const matches = data.response.slice(0, 5).map(g => {
      const statusNum = g.status?.clock;
      const period = g.periods?.current;
      const live = g.status?.halftime === false && period > 0 && !['Finished','Scheduled'].includes(g.status?.long);
      const crowdA = 35 + Math.floor(Math.random() * 30);
      return {
        id: g.id,
        league: 'NBA',
        teamA: g.teams.home.nickname,
        teamB: g.teams.visitors.nickname,
        scoreA: String(g.scores.home.points || '—'),
        scoreB: String(g.scores.visitors.points || '—'),
        quarter: period ? `Q${period} ${statusNum||''}` : g.status?.long,
        status: live ? 'live' : g.status?.long === 'Finished' ? 'ended' : 'upcoming',
        crowdA,
        crowdB: 100 - crowdA,
        vol: ['NORMAL','HIGH','EXTREME'][Math.floor(Math.random()*3)],
        momentum: 35 + Math.floor(Math.random()*30)
      };
    });

    return res.json({ success: true, source: 'live', matches });
  } catch (err) {
    console.error('NBA API error:', err);
    return res.json(getMockNBA());
  }
}

function getMockNBA() {
  return {
    success: true,
    source: 'mock',
    note: 'Set RAPIDAPI_KEY env var. Get free key at rapidapi.com/api-sports/api/api-nba',
    matches: [
      {
        id: 'nba-lal-chi', league: 'NBA', teamA: 'Lakers', teamB: 'Bulls',
        scoreA: `${85+Math.floor(Math.random()*15)}`, scoreB: `${88+Math.floor(Math.random()*10)}`,
        quarter: `Q3 ${Math.floor(Math.random()*12)}:${String(Math.floor(Math.random()*60)).padStart(2,'0')}`,
        status: 'live', crowdA: 47, crowdB: 53, vol: 'HIGH', momentum: 58
      },
      {
        id: 'nba-gsw-bos', league: 'NBA', teamA: 'Warriors', teamB: 'Celtics',
        scoreA: `${108+Math.floor(Math.random()*15)}`, scoreB: `${104+Math.floor(Math.random()*10)}`,
        quarter: `Q4 ${Math.floor(Math.random()*5)}:${String(Math.floor(Math.random()*60)).padStart(2,'0')}`,
        status: 'live', crowdA: 54, crowdB: 46, vol: 'EXTREME', momentum: 46
      },
      {
        id: 'nba-mia-bkn', league: 'NBA', teamA: 'Heat', teamB: 'Nets',
        scoreA: '—', scoreB: '—', quarter: 'Tonight 8PM ET',
        status: 'upcoming', crowdA: 52, crowdB: 48, vol: 'NORMAL', momentum: 50
      },
      {
        id: 'nba-phi-tor', league: 'NBA', teamA: '76ers', teamB: 'Raptors',
        scoreA: `${115+Math.floor(Math.random()*10)}`, scoreB: `${98+Math.floor(Math.random()*10)}`,
        quarter: 'Final', status: 'ended', crowdA: 64, crowdB: 36, vol: 'NORMAL', momentum: 35
      }
    ]
  };
}
