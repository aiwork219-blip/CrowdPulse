// api/tennis.js
// Free: api-tennis.com (free tier available)
// OR use RapidAPI tennis API
// Set in Vercel: RAPIDAPI_KEY (same key works for tennis too)

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');

  const RAPIDAPI_KEY = process.env.RAPIDAPI_KEY;

  if (!RAPIDAPI_KEY || RAPIDAPI_KEY === 'YOUR_KEY_HERE') {
    return res.json(getMockTennis());
  }

  try {
    const today = new Date().toISOString().split('T')[0];
    const response = await fetch(
      `https://tennis-live-data.p.rapidapi.com/matches-by-date/${today}`,
      {
        headers: {
          'x-rapidapi-key': RAPIDAPI_KEY,
          'x-rapidapi-host': 'tennis-live-data.p.rapidapi.com'
        }
      }
    );
    const data = await response.json();

    if (!data.results || data.results.length === 0) {
      return res.json(getMockTennis());
    }

    const matches = data.results.slice(0, 5).map(m => {
      const crowdA = 35 + Math.floor(Math.random() * 30);
      return {
        id: m.id,
        league: m.tournament?.name || 'ATP/WTA',
        teamA: m.home_team || 'Player A',
        teamB: m.away_team || 'Player B',
        scoreA: m.home_score?.sets ? m.home_score.sets.join('-') : '—',
        scoreB: m.away_score?.sets ? m.away_score.sets.join('-') : '—',
        setInfo: `Set ${(m.home_score?.sets?.length || 1)}`,
        status: m.status === 'inprogress' ? 'live' : m.status === 'finished' ? 'ended' : 'upcoming',
        surface: m.ground_type || 'Hard',
        crowdA,
        crowdB: 100 - crowdA,
        vol: ['NORMAL','HIGH','EXTREME'][Math.floor(Math.random()*3)],
        momentum: 35 + Math.floor(Math.random()*30)
      };
    });

    return res.json({ success: true, source: 'live', matches });
  } catch (err) {
    console.error('Tennis API error:', err);
    return res.json(getMockTennis());
  }
}

function getMockTennis() {
  return {
    success: true,
    source: 'mock',
    note: 'Set RAPIDAPI_KEY. Search "tennis live data" on rapidapi.com',
    matches: [
      {
        id: 'ten-djk-alc', league: 'Wimbledon', teamA: 'Djokovic', teamB: 'Alcaraz',
        scoreA: '6-4, 3', scoreB: '5', setInfo: 'Set 2',
        status: 'live', surface: 'Grass', crowdA: 43, crowdB: 57, vol: 'HIGH', momentum: 60
      },
      {
        id: 'ten-nad-med', league: 'French Open', teamA: 'Nadal', teamB: 'Medvedev',
        scoreA: '6-3, 6-2', scoreB: '0-0', setInfo: 'Completed',
        status: 'ended', surface: 'Clay', crowdA: 68, crowdB: 32, vol: 'NORMAL', momentum: 35
      },
      {
        id: 'ten-sin-gau', league: 'US Open', teamA: 'Sinner', teamB: 'Gauff',
        scoreA: '4', scoreB: '6', setInfo: 'Set 1',
        status: 'live', surface: 'Hard', crowdA: 52, crowdB: 48, vol: 'HIGH', momentum: 48
      },
      {
        id: 'ten-rub-tsit', league: 'ATP Masters', teamA: 'Ruud', teamB: 'Tsitsipas',
        scoreA: '—', scoreB: '—', setInfo: 'Today 3PM',
        status: 'upcoming', surface: 'Clay', crowdA: 50, crowdB: 50, vol: 'NORMAL', momentum: 50
      }
    ]
  };
}
